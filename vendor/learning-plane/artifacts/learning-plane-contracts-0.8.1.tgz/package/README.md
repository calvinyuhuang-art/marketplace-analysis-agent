# @learning-plane/contracts

Shared Learning Plane contracts.

**LP1:** Zod schemas for agent registration, capabilities, health, and system status.

- Envelope `schemaVersion` `"1.0"` remains frozen (payload versions still draft until later milestones).
- Capability vocabulary frozen from LP0.
- Supported Learning Plane contract versions for registration intersection: `["1.0"]`.
