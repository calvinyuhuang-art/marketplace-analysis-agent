# @learning-plane/client

Typed, transport-only HTTP client for the Sales OS Learning Plane.

## Surfaces

- `LearningPlaneBootstrapClient` — operator-token registration (bootstrap only)
- `LearningPlaneAgentClient` — agent API key for publish/ack/health/inspection
- `verifyLearningPlaneDeliverySignature()` — LP2 HMAC verification over **raw** callback bytes

## Non-goals

No agent database, domain types, background workers, governance, or server imports.
